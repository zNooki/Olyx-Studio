# Olyx Studio Store

Boutique avec :

- Inscription / connexion via Supabase
- Paiement Stripe Checkout
- Webhook Stripe `checkout.session.completed`
- Sauvegarde automatique des achats dans Supabase
- Page `Mon compte`
- Historique d'achat
- Bouton téléchargement réservé aux acheteurs

## 1. Installation

```bash
npm install
cp .env.example .env
```

Remplis le fichier `.env`.

## 2. Supabase

1. Crée un projet sur Supabase.
2. Va dans `SQL Editor`.
3. Colle le contenu de `supabase/schema.sql`.
4. Va dans `Authentication > Providers > Email`.
5. Active l'authentification par email.
6. Pour tester plus vite, tu peux désactiver la confirmation email.

Tu dois récupérer :

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`

La `SERVICE_ROLE_KEY` doit rester privée. Ne la mets jamais dans le HTML.

## 3. Stripe

Tu dois créer des produits/prix dans Stripe.

Important : dans `.env`, il faut mettre les `price_...`, pas les `prod_...`.

Exemple :

```env
STRIPE_PRICE_PECHE=price_123
```

## 4. Lancer le site

```bash
npm run dev
```

Site :

```text
http://localhost:4242
```

## 5. Webhook Stripe en local

Installe Stripe CLI, puis :

```bash
stripe login
stripe listen --forward-to localhost:4242/api/stripe-webhook
```

Stripe va afficher un secret `whsec_...`.

Mets-le dans `.env` :

```env
STRIPE_WEBHOOK_SECRET=whsec_...
```

## 6. Fonctionnement

1. Le client crée un compte.
2. Il clique sur acheter.
3. Le serveur crée une session Stripe Checkout.
4. Après paiement, Stripe appelle le webhook.
5. Le webhook ajoute l'achat dans Supabase.
6. Le client voit son achat dans `Mon compte`.
7. Le bouton télécharger redirige vers le lien GoFile configuré dans `.env`.

## 7. Mise en production

Quand tu publies le site sur Render, Railway ou autre :

- change `SITE_URL`
- utilise les clés Stripe en production
- configure le webhook Stripe production vers :

```text
https://ton-site.com/api/stripe-webhook
```



## Correction importante : Live Server / localhost:5500

Si tu ouvres le site avec VS Code Live Server sur :

```text
http://localhost:5500
```

le fichier `public/app.js` appelle automatiquement le backend Node.js sur :

```text
http://localhost:4242
```

Donc il faut toujours lancer le serveur avec :

```bash
npm install
npm run dev
```

Puis ouvrir le site soit sur :

```text
http://localhost:4242
```

ou avec Live Server :

```text
http://localhost:5500
```

## Tester la configuration

Ouvre :

```text
http://localhost:4242/api/health
```

Si tout est bon, tu dois voir :

```json
{ "ok": true, "missing": [] }
```

Si `missing` contient des noms, il manque une variable dans `.env`.

## Sécurité

Tu as partagé des clés privées dans des captures. Après les tests, régénère :

- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`
- `SUPABASE_SERVICE_ROLE_KEY`

Ne mets jamais ces clés dans le HTML. Elles doivent rester uniquement dans `.env` côté serveur.
